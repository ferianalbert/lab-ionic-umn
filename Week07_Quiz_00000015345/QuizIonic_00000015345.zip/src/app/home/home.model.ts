
export class UKM{
    constructor(
        public id: string,
        public title: string,
        public ukm_desc: string,
        public imageUrl: string
    ) { }
}